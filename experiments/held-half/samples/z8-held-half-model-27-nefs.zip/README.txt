These 27 NEFs were extracted without repair from the supplied held-HALF
QEMU model run. They contain synthetic test patterns, not photographs taken
by a Nikon camera. One half-press was held for 14.041163562 virtual seconds.
At release 26 captures and 5 encodes were observed; one later capture and
approximately 63.3 virtual seconds of encoding drain completed the files.

All full 8280x5520 14-bit CFA arrays matched their corresponding 640x480
synthetic inputs under the model's CFA-preserving expansion. The independent
audit used rawpy 0.27.1 / LibRaw 0.22.1. No per-frame producer comparison,
second RAW decoder, real-camera operation or 10 fps was established.

This archive contains no full firmware, key, camera calibration or card image.
Hashes are listed in SHA256.json. Reproduction source, exact synthetic inputs,
scope, attribution and limitations accompany the held-half experiment in:
https://github.com/Ivan-mato/nikon-z8-halfpress-raw-precapture

Treat these as research samples, not a camera compatibility claim. The files
are not an installation package. The project does not claim rights over
Nikon's NEF format or third-party material; synthetic sample data are supplied
under the repository's GPL-3.0-only license.
